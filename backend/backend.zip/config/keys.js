module.exports = {
  mongoURI: "mongodb+srv://oreo:1234abcd@cluster0.jwjnk.mongodb.net/dass11?retryWrites=true&w=majority",
  secretKey: "xy"
};
